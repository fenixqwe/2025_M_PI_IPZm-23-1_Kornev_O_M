package store

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"github.com/google/uuid"
	"time"
)

type Idea struct {
	IdeaID      uuid.UUID `json:"idea_id"`
	Title       string    `json:"title"`
	Description string    `json:"description"`
	IsArchived  bool      `json:"is_archived"`
	CreatedAt   time.Time `json:"created_at"`
	UpdatedAt   time.Time `json:"updated_at"`
	BoardID     uuid.UUID `json:"board_id"`
}

type IdeasStore struct {
	db *sql.DB
}

func (s *IdeasStore) Create(ctx context.Context, idea *Idea) error {
	query := `INSERT INTO ideas (title, description, board_id) VALUES ($1, $2, $3) RETURNING *`

	ctx, cancel := context.WithTimeout(ctx, QueryContextDuration)
	defer cancel()

	err := s.db.QueryRowContext(
		ctx,
		query,
		idea.Title,
		idea.Description,
		idea.BoardID).Scan(&idea.IdeaID, &idea.Title, &idea.Description, &idea.IsArchived, &idea.CreatedAt, &idea.UpdatedAt, &idea.BoardID)
	if err != nil {
		return err
	}

	return nil
}

func (s *IdeasStore) GetAllForBoard(ctx context.Context, boardID string, isArchived *bool) ([]Idea, error) {
	query := `SELECT * FROM ideas WHERE board_id = $1 AND (is_archived = COALESCE($2, is_archived)) ORDER BY is_archived ASC`

	fmt.Println(isArchived)
	ctx, cancel := context.WithTimeout(ctx, QueryContextDuration)
	defer cancel()

	rows, err := s.db.QueryContext(ctx, query, boardID, isArchived)
	if err != nil {
		return nil, err
	}

	defer func(rows *sql.Rows) {
		err := rows.Close()
		if err != nil {
			return
		}
	}(rows)

	var ideas []Idea

	for rows.Next() {
		var idea Idea
		var description sql.NullString
		err := rows.Scan(&idea.IdeaID, &idea.Title, &description, &idea.IsArchived, &idea.CreatedAt, &idea.UpdatedAt, &idea.BoardID)
		if err != nil {
			return nil, err
		}
		idea.Description = description.String
		ideas = append(ideas, idea)
	}

	return ideas, nil
}

func (s *IdeasStore) GetCertain(ctx context.Context, id string) (*Idea, error) {
	query := `SELECT * FROM ideas WHERE idea_id = $1`

	ctx, cancel := context.WithTimeout(ctx, QueryContextDuration)
	defer cancel()

	var idea Idea

	err := s.db.QueryRowContext(ctx, query, id).Scan(
		&idea.IdeaID,
		&idea.Title,
		&idea.Description,
		&idea.IsArchived,
		&idea.CreatedAt,
		&idea.UpdatedAt,
		&idea.BoardID)

	if err != nil {
		switch {
		case errors.Is(err, sql.ErrNoRows):
			return nil, ErrNotFound
		default:
			return nil, err
		}
	}

	return &idea, nil
}

func (s *IdeasStore) Search(ctx context.Context, boardID string, searchSting string) ([]Idea, error) {
	query := `SELECT * FROM ideas 
         WHERE board_id = $1
         AND (title LIKE '%' || $2 || '%' OR description LIKE '%' || $2 || '%')
         ORDER BY is_archived ASC`

	ctx, cancel := context.WithTimeout(ctx, QueryContextDuration)
	defer cancel()

	rows, err := s.db.QueryContext(ctx, query, boardID, searchSting)

	if err != nil {
		return nil, err
	}
	defer func(rows *sql.Rows) {
		err := rows.Close()
		if err != nil {
			return
		}
	}(rows)

	var ideas []Idea

	for rows.Next() {
		var idea Idea
		var description sql.NullString
		err := rows.Scan(&idea.IdeaID, &idea.Title, &description, &idea.IsArchived, &idea.CreatedAt, &idea.UpdatedAt, &idea.BoardID)
		if err != nil {
			return nil, err
		}
		idea.Description = description.String
		ideas = append(ideas, idea)
	}

	return ideas, nil
}

func (s *IdeasStore) Delete(ctx context.Context, id string) error {
	query := `DELETE FROM ideas WHERE idea_id = $1`

	ctx, cancel := context.WithTimeout(ctx, QueryContextDuration)
	defer cancel()

	res, err := s.db.ExecContext(ctx, query, id)
	if err != nil {
		return err
	}

	rows, err := res.RowsAffected()
	if err != nil {
		return err
	}

	if rows == 0 {
		return ErrNotFound
	}

	return nil
}

func (s *IdeasStore) Update(ctx context.Context, idea *Idea) error {
	query := `UPDATE ideas SET title = $1, description = $2, is_archived = $3 WHERE idea_id = $4 RETURNING *`

	ctx, cancel := context.WithTimeout(ctx, QueryContextDuration)
	defer cancel()

	_, err := s.db.ExecContext(ctx, query, idea.Title, idea.Description, idea.IsArchived, idea.IdeaID)
	if err != nil {
		return err
	}

	return nil
}
