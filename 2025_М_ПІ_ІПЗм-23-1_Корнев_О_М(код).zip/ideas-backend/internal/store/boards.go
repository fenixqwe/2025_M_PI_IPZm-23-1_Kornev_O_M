package store

import (
	"context"
	"database/sql"
	"errors"
	"github.com/google/uuid"
	"time"
)

type Board struct {
	BoardID   uuid.UUID `json:"board_id"`
	Title     string    `json:"title"`
	CreatedAt time.Time `json:"created_at"`
	UpdatedAt time.Time `json:"updated_at"`
}

type BoardsStore struct {
	db *sql.DB
}

func (s *BoardsStore) Create(ctx context.Context, board *Board) error {
	query := `INSERT INTO boards (title) VALUES ($1) RETURNING *`

	ctx, cancel := context.WithTimeout(ctx, QueryContextDuration)
	defer cancel()

	err := s.db.QueryRowContext(
		ctx,
		query,
		board.Title).Scan(&board.BoardID, &board.Title, &board.CreatedAt, &board.UpdatedAt)
	if err != nil {
		return err
	}

	return nil
}

func (s *BoardsStore) GetAll(ctx context.Context) ([]Board, error) {
	query := `SELECT * FROM boards ORDER BY created_at DESC`

	ctx, cancel := context.WithTimeout(ctx, QueryContextDuration)
	defer cancel()

	rows, err := s.db.QueryContext(ctx, query)

	if err != nil {
		return nil, err
	}
	defer func(rows *sql.Rows) {
		err := rows.Close()
		if err != nil {
			return
		}
	}(rows)

	var boards []Board

	for rows.Next() {
		var board Board
		err := rows.Scan(&board.BoardID, &board.Title, &board.CreatedAt, &board.UpdatedAt)
		if err != nil {
			return nil, err
		}
		boards = append(boards, board)
	}

	return boards, nil
}

func (s *BoardsStore) GetCertain(ctx context.Context, id string) (*Board, error) {
	query := `SELECT * FROM boards WHERE board_id = $1`

	ctx, cancel := context.WithTimeout(ctx, QueryContextDuration)
	defer cancel()

	var board Board

	err := s.db.QueryRowContext(ctx, query, id).Scan(
		&board.BoardID,
		&board.Title,
		&board.CreatedAt,
		&board.UpdatedAt)

	if err != nil {
		switch {
		case errors.Is(err, sql.ErrNoRows):
			return nil, ErrNotFound
		default:
			return nil, err
		}
	}

	return &board, nil
}

func (s *BoardsStore) Search(ctx context.Context, searchSting string) ([]Board, error) {
	query := `SELECT * FROM boards 
         WHERE title LIKE '%' || $1 || '%'
         ORDER BY created_at DESC`

	ctx, cancel := context.WithTimeout(ctx, QueryContextDuration)
	defer cancel()

	rows, err := s.db.QueryContext(ctx, query, searchSting)

	if err != nil {
		return nil, err
	}
	defer func(rows *sql.Rows) {
		err := rows.Close()
		if err != nil {
			return
		}
	}(rows)

	var boards []Board

	for rows.Next() {
		var board Board
		err := rows.Scan(&board.BoardID, &board.Title, &board.CreatedAt, &board.UpdatedAt)
		if err != nil {
			return nil, err
		}
		boards = append(boards, board)
	}

	return boards, nil
}

func (s *BoardsStore) Delete(ctx context.Context, id string) error {
	query := `DELETE FROM boards WHERE board_id = $1`

	ctx, cancel := context.WithTimeout(ctx, QueryContextDuration)
	defer cancel()

	res, err := s.db.ExecContext(ctx, query, id)
	if err != nil {
		return err
	}

	rows, err := res.RowsAffected()
	if err != nil {
		return err
	}

	if rows == 0 {
		return ErrNotFound
	}

	return nil
}

func (s *BoardsStore) Update(ctx context.Context, board *Board) error {
	query := `UPDATE boards SET title = $1 WHERE board_id = $2 RETURNING *`

	ctx, cancel := context.WithTimeout(ctx, QueryContextDuration)
	defer cancel()

	_, err := s.db.ExecContext(ctx, query, board.Title, board.BoardID)
	if err != nil {
		return err
	}

	return nil
}
