package store

import (
	"context"
	"database/sql"
	"errors"
	"time"
)

var (
	ErrNotFound          = errors.New("record not found")
	QueryContextDuration = time.Second * 5
)

type Storage struct {
	Boards interface {
		Create(context.Context, *Board) error
		GetAll(context.Context) ([]Board, error)
		GetCertain(context.Context, string) (*Board, error)
		Search(context.Context, string) ([]Board, error)
		Delete(context.Context, string) error
		Update(context.Context, *Board) error
	}
	Ideas interface {
		Create(context.Context, *Idea) error
		GetAllForBoard(context.Context, string, *bool) ([]Idea, error)
		GetCertain(context.Context, string) (*Idea, error)
		Search(context.Context, string, string) ([]Idea, error)
		Delete(context.Context, string) error
		Update(context.Context, *Idea) error
	}
}

func NewStorage(db *sql.DB) *Storage {
	return &Storage{
		Boards: &BoardsStore{db},
		Ideas:  &IdeasStore{db},
	}
}
