-- +goose Up

CREATE TABLE ideas (
    idea_id   UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    title      TEXT      NOT NULL,
    description      TEXT,
    is_archived BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
    board_id UUID NOT NULL REFERENCES boards(board_id) ON DELETE CASCADE
);

-- +goose Down

DROP TABLE ideas;