package main

import (
	"net/http"
)

func (app *application) internalServerError(w http.ResponseWriter, r *http.Request, err error) {
	app.logger.Errorw("internal server error", "method", r.Method, "path", r.URL.Path, "error", err)

	err = writeJSONError(w, http.StatusInternalServerError, "An internal server error has occurred.")
	if err != nil {
		return
	}
}

func (app *application) badRequestResponse(w http.ResponseWriter, r *http.Request, err error) {
	app.logger.Warnf("bad request", "method", r.Method, "path", r.URL.Path, "error", err.Error())

	err = writeJSONError(w, http.StatusBadRequest, err.Error())
	if err != nil {
		return
	}
}

func (app *application) notFoundResponse(w http.ResponseWriter, r *http.Request, err error) {
	app.logger.Warnf("not found error", "method", r.Method, "path", r.URL.Path, "error", err.Error())

	err = writeJSONError(w, http.StatusNotFound, "not found")
	if err != nil {
		return
	}
}
