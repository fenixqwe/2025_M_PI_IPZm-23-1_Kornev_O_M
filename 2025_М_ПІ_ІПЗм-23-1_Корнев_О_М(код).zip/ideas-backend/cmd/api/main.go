package main

import (
	"database/sql"
	"github.com/joho/godotenv"
	_ "github.com/lib/pq"
	"go.uber.org/zap"
	"ideas-backend/internal/db"
	"ideas-backend/internal/env"
	"ideas-backend/internal/store"
)

const version = "0.0.1"

// @title BoardFlow API
// @description API for BoardFlow, vue state-managers testing.
// @termsOfService http://swagger.io/terms/

// @contact.name API Support
// @contact.url http://www.swagger.io/support
// @contact.email support@swagger.io

// @license.name Apache 2.0
// @license.url http://www.apache.org/licenses/LICENSE-2.0.html

// @BasePath /v1
func main() {
	err := godotenv.Load(".env")
	if err != nil {
		return
	}

	cfg := config{
		addr:   env.GetString("ADDR", ":5000"),
		apiURL: env.GetString("EXTERNAL_URL", "localhost:5000/"),
		db: dbConfig{
			addr:         env.GetString("DB_ADDR", "postgres://user:adminpassword@localhost/ideasdb?sslmode=disable"),
			maxOpenConns: env.GetInt("DB_MAX_OPEN_CONNS", 30),
			maxIdleConns: env.GetInt("DB_MAX_IDLE_CONNS", 30),
			maxIdleTime:  env.GetString("DB_MAX_IDLE_TIME", "15m"),
		},
		env: env.GetString("ENV", "development"),
	}

	// Logger
	logger := zap.Must(zap.NewProduction()).Sugar()
	defer func(logger *zap.SugaredLogger) {
		err := logger.Sync()
		if err != nil {
			return
		}
	}(logger)

	// Database
	dbase, err := db.New(cfg.db.addr, cfg.db.maxOpenConns, cfg.db.maxIdleConns, cfg.db.maxIdleTime)
	if err != nil {
		logger.Fatal(err)
	}

	defer func(dbase *sql.DB) {
		err := dbase.Close()
		if err != nil {
			logger.Fatal(err)
		}
	}(dbase)
	logger.Info("Connected to database")

	storage := store.NewStorage(dbase)

	app := &application{
		config: cfg,
		store:  storage,
		logger: logger,
	}

	mux := app.mount()
	logger.Fatal(app.listen(mux))
}
