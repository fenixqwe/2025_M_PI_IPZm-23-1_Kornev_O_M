package main

import (
	"context"
	"errors"
	"github.com/go-chi/chi/v5"
	"ideas-backend/internal/store"
	"net/http"
)

type boardKey string

const boardCtx boardKey = "board"

type CreateBoardPayload struct {
	Title string `json:"title" validate:"required,min=3,max=100"`
}

type UpdateBoardPayload struct {
	Title *string `json:"title" validate:"omitempty,min=3,max=100"`
}

// CreateBoard godoc
// @Summary      Creates a board
// @Description  Creates a board by title
// @Tags         boards
// @Accept       json
// @Produce      json
// @Param        input  body  CreateBoardPayload  true  "Board creation payload"
// @Success      200  {object}  store.Board
// @Failure      400  {object}  error
// @Failure      404  {object}  error
// @Failure      500  {object}  error
// @Router       /boards/create [post]
func (app *application) createBoardHandler(w http.ResponseWriter, r *http.Request) {
	var payload CreateBoardPayload
	if err := readJSON(w, r, &payload); err != nil {
		app.badRequestResponse(w, r, err)
		return
	}

	if err := Validate.Struct(payload); err != nil {
		app.badRequestResponse(w, r, err)
		return
	}

	board := &store.Board{
		Title: payload.Title,
	}

	ctx := r.Context()

	if err := app.store.Boards.Create(ctx, board); err != nil {
		app.internalServerError(w, r, err)
		return
	}

	if err := app.jsonResponse(w, http.StatusCreated, board); err != nil {
		app.internalServerError(w, r, err)
		return
	}
}

// GetCertainBoard godoc
// @Summary      Gets a certain board
// @Description  Gets a certain board by board_id
// @Tags         boards
// @Accept       json
// @Produce      json
// @Param        boardID  path  string  true  "Board ID"
// @Success      200  {object}  store.Board
// @Failure      400  {object}  error
// @Failure      404  {object}  error
// @Failure      500  {object}  error
// @Router       /boards/{boardID} [get]
func (app *application) getCertainBoardHandler(w http.ResponseWriter, r *http.Request) {
	board := getBoardFromCtx(r)

	if err := app.jsonResponse(w, http.StatusOK, board); err != nil {
		app.internalServerError(w, r, err)
		return
	}
}

// GetAllBoards godoc
// @Summary      Gets all boards
// @Description  Gets all boards
// @Tags         boards
// @Accept       json
// @Produce      json
// @Success      200  {object}  store.Board
// @Failure      400  {object}  error
// @Failure      404  {object}  error
// @Failure      500  {object}  error
// @Router       /boards/getAllBoards [get]
func (app *application) getAllBoardsHandler(w http.ResponseWriter, r *http.Request) {
	ctx := r.Context()

	boards, err := app.store.Boards.GetAll(ctx)

	if err != nil {
		switch {
		case errors.Is(err, store.ErrNotFound):
			app.notFoundResponse(w, r, err)
		default:
			app.internalServerError(w, r, err)
		}
		return
	}

	if err := app.jsonResponse(w, http.StatusOK, boards); err != nil {
		app.internalServerError(w, r, err)
		return
	}
}

// SearchBoards godoc
// @Summary      Search boards
// @Description  Searches for boards by a query string
// @Tags         boards
// @Accept       json
// @Produce      json
// @Param        query  query  string  false  "Search query string"
// @Success      200  {array}  store.Board
// @Failure      400  {object}  error
// @Failure      404  {object}  error
// @Failure      500  {object}  error
// @Router       /boards/search [get]
func (app *application) searchBoardsHandler(w http.ResponseWriter, r *http.Request) {
	ctx := r.Context()

	searchParam := r.URL.Query().Get("query")

	boards, err := app.store.Boards.Search(ctx, searchParam)

	if err != nil {
		switch {
		case errors.Is(err, store.ErrNotFound):
			app.notFoundResponse(w, r, err)
		default:
			app.internalServerError(w, r, err)
		}
		return
	}

	if err := app.jsonResponse(w, http.StatusOK, boards); err != nil {
		app.internalServerError(w, r, err)
		return
	}
}

// DeleteBoard godoc
// @Summary      Delete a board
// @Description  Deletes a board by its ID
// @Tags         boards
// @Accept       json
// @Produce      json
// @Param        boardID  path  string  true  "Board ID"
// @Success      204  {string}  "No content"
// @Failure      400  {object}  error
// @Failure      404  {object}  error
// @Failure      500  {object}  error
// @Router       /boards/{boardID} [delete]
func (app *application) deleteBoardHandler(w http.ResponseWriter, r *http.Request) {
	idParam := chi.URLParam(r, "boardID")
	ctx := r.Context()

	if err := app.store.Boards.Delete(ctx, idParam); err != nil {
		switch {
		case errors.Is(err, store.ErrNotFound):
			app.notFoundResponse(w, r, err)
		default:
			app.internalServerError(w, r, err)
		}
	}

	w.WriteHeader(http.StatusNoContent)
}

// UpdateBoard godoc
// @Summary      Update a board
// @Description  Updates a board by its ID
// @Tags         boards
// @Accept       json
// @Produce      json
// @Param        boardID  path  string  true  "Board ID"
// @Param        input  body  UpdateBoardPayload  true  "Board update payload"
// @Success      200  {object}  store.Board
// @Failure      400  {object}  error
// @Failure      404  {object}  error
// @Failure      500  {object}  error
// @Router       /boards/{boardID} [patch]
func (app *application) updateBoardHandler(w http.ResponseWriter, r *http.Request) {
	board := getBoardFromCtx(r)

	var payload UpdateBoardPayload
	if err := readJSON(w, r, &payload); err != nil {
		app.badRequestResponse(w, r, err)
		return
	}

	if err := Validate.Struct(payload); err != nil {
		app.badRequestResponse(w, r, err)
		return
	}

	if payload.Title != nil {
		board.Title = *payload.Title
	}

	if err := app.store.Boards.Update(r.Context(), board); err != nil {
		app.internalServerError(w, r, err)
		return
	}

	if err := app.jsonResponse(w, http.StatusOK, board); err != nil {
		app.internalServerError(w, r, err)
		return
	}
}

func (app *application) boardsContextMiddleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		idParam := chi.URLParam(r, "boardID")

		ctx := r.Context()

		board, err := app.store.Boards.GetCertain(ctx, idParam)

		if err != nil {
			switch {
			case errors.Is(err, store.ErrNotFound):
				app.notFoundResponse(w, r, err)
			default:
				app.internalServerError(w, r, err)
			}
			return
		}

		ctx = context.WithValue(ctx, boardCtx, board)
		next.ServeHTTP(w, r.WithContext(ctx))
	})
}

func getBoardFromCtx(r *http.Request) *store.Board {
	board, _ := r.Context().Value(boardCtx).(*store.Board)
	return board
}
