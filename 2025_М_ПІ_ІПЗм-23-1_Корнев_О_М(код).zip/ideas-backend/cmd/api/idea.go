package main

import (
	"context"
	"errors"
	"github.com/go-chi/chi/v5"
	"github.com/google/uuid"
	"ideas-backend/internal/store"
	"net/http"
)

type ideaKey string

const ideaCtx ideaKey = "idea"

type CreateIdeaPayload struct {
	Title       string    `json:"title" validate:"required,min=3,max=100"`
	Description string    `json:"description" validate:"omitempty,min=3,max=255"`
	BoardID     uuid.UUID `json:"board_id" validate:"required"`
}

type UpdateIdeaPayload struct {
	Title       *string `json:"title" validate:"omitempty,min=3,max=100"`
	Description *string `json:"description" validate:"omitempty,min=3,max=255"`
	IsArchived  *bool   `json:"is_archived" validate:"omitempty"`
}

// CreateIdea godoc
// @Summary      Creates an idea
// @Description  Creates an idea by params
// @Tags         ideas
// @Accept       json
// @Produce      json
// @Param        input  body  CreateIdeaPayload  true  "Idea creation payload"
// @Success      200  {object}  store.Idea
// @Failure      400  {object}  error
// @Failure      404  {object}  error
// @Failure      500  {object}  error
// @Router       /ideas/create [post]
func (app *application) createIdeaHandler(w http.ResponseWriter, r *http.Request) {
	var payload CreateIdeaPayload
	if err := readJSON(w, r, &payload); err != nil {
		app.badRequestResponse(w, r, err)
		return
	}

	if err := Validate.Struct(payload); err != nil {
		app.badRequestResponse(w, r, err)
		return
	}

	idea := &store.Idea{
		Title:       payload.Title,
		Description: payload.Description,
		BoardID:     payload.BoardID,
	}

	ctx := r.Context()

	if err := app.store.Ideas.Create(ctx, idea); err != nil {
		app.internalServerError(w, r, err)
		return
	}

	if err := app.jsonResponse(w, http.StatusCreated, idea); err != nil {
		app.internalServerError(w, r, err)
		return
	}
}

// GetAllIdeas godoc
// @Summary      Get all ideas for a board
// @Description  Retrieves all ideas for a given board, with an optional filter for archived status.
// @Tags         ideas
// @Accept       json
// @Produce      json
// @Param        boardID     path      string  true   "Board ID"
// @Param        isArchived  query     bool    false  "Filter by archived status (true/false)"
// @Success      200  {array}   store.Idea
// @Failure      400  {object}  error
// @Failure      404  {object}  error
// @Failure      500  {object}  error
// @Router       /ideas/board/{boardID} [get]
func (app *application) getAllIdeasHandler(w http.ResponseWriter, r *http.Request) {
	boardID := chi.URLParam(r, "boardID")

	query := r.URL.Query().Get("isArchived")

	var isArchived *bool
	if query != "" {
		parsed := query == "true"
		isArchived = &parsed
	}

	ctx := r.Context()

	ideas, err := app.store.Ideas.GetAllForBoard(ctx, boardID, isArchived)

	if err != nil {
		switch {
		case errors.Is(err, store.ErrNotFound):
			app.notFoundResponse(w, r, err)
		default:
			app.internalServerError(w, r, err)
		}
		return
	}

	if err := app.jsonResponse(w, http.StatusOK, ideas); err != nil {
		app.internalServerError(w, r, err)
		return
	}
}

// SearchIdeas godoc
// @Summary      Search ideas in a board
// @Description  Searches for ideas in a given board based on a query string.
// @Tags         ideas
// @Accept       json
// @Produce      json
// @Param        boardID  path   string  true   "Board ID"
// @Param        query    query  string  false  "Search query string"
// @Success      200  {array}   store.Idea
// @Failure      400  {object}  error
// @Failure      404  {object}  error
// @Failure      500  {object}  error
// @Router       /ideas/board/{boardID}/search [get]
func (app *application) searchIdeasHandler(w http.ResponseWriter, r *http.Request) {
	boardID := chi.URLParam(r, "boardID")
	ctx := r.Context()

	searchParam := r.URL.Query().Get("query")

	ideas, err := app.store.Ideas.Search(ctx, boardID, searchParam)

	if err != nil {
		switch {
		case errors.Is(err, store.ErrNotFound):
			app.notFoundResponse(w, r, err)
		default:
			app.internalServerError(w, r, err)
		}
		return
	}

	if err := app.jsonResponse(w, http.StatusOK, ideas); err != nil {
		app.internalServerError(w, r, err)
		return
	}
}

// DeleteIdea godoc
// @Summary      Delete an idea
// @Description  Deletes an idea by its ID.
// @Tags         ideas
// @Param        ideaID  path   string  true  "Idea ID"
// @Success      204  "No Content"
// @Failure      400  {object}  error
// @Failure      404  {object}  error
// @Failure      500  {object}  error
// @Router       /ideas/{ideaID} [delete]
func (app *application) deleteIdeaHandler(w http.ResponseWriter, r *http.Request) {
	idParam := chi.URLParam(r, "ideaID")
	ctx := r.Context()

	if err := app.store.Ideas.Delete(ctx, idParam); err != nil {
		switch {
		case errors.Is(err, store.ErrNotFound):
			app.notFoundResponse(w, r, err)
		default:
			app.internalServerError(w, r, err)
		}
	}

	w.WriteHeader(http.StatusNoContent)
}

func (app *application) updateIdeaHandler(w http.ResponseWriter, r *http.Request) {
	idea := getIdeaFromCtx(r)

	var payload UpdateIdeaPayload
	if err := readJSON(w, r, &payload); err != nil {
		app.badRequestResponse(w, r, err)
		return
	}

	if err := Validate.Struct(payload); err != nil {
		app.badRequestResponse(w, r, err)
		return
	}

	if payload.Title != nil {
		idea.Title = *payload.Title
	}
	if payload.Description != nil {
		idea.Description = *payload.Description
	}
	if payload.IsArchived != nil {
		idea.IsArchived = *payload.IsArchived
	}

	if err := app.store.Ideas.Update(r.Context(), idea); err != nil {
		app.internalServerError(w, r, err)
		return
	}

	if err := app.jsonResponse(w, http.StatusOK, idea); err != nil {
		app.internalServerError(w, r, err)
		return
	}
}

// UpdateIdea godoc
// @Summary      Update an idea
// @Description  Updates an existing idea's title, description, or archived status.
// @Tags         ideas
// @Accept       json
// @Produce      json
// @Param        ideaID  path   string            true  "Idea ID"
// @Param        input   body   UpdateIdeaPayload true  "Idea update payload"
// @Success      200  {object}  store.Idea
// @Failure      400  {object}  error
// @Failure      404  {object}  error
// @Failure      500  {object}  error
// @Router       /ideas/{ideaID} [patch]
func (app *application) ideasContextMiddleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		idParam := chi.URLParam(r, "ideaID")

		ctx := r.Context()

		idea, err := app.store.Ideas.GetCertain(ctx, idParam)

		if err != nil {
			switch {
			case errors.Is(err, store.ErrNotFound):
				app.notFoundResponse(w, r, err)
			default:
				app.internalServerError(w, r, err)
			}
			return
		}

		ctx = context.WithValue(ctx, ideaCtx, idea)
		next.ServeHTTP(w, r.WithContext(ctx))
	})
}

func getIdeaFromCtx(r *http.Request) *store.Idea {
	idea, _ := r.Context().Value(ideaCtx).(*store.Idea)
	return idea
}
