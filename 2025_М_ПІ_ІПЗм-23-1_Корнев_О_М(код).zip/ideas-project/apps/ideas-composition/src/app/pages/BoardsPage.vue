<script setup lang="ts">
import { BoardList, DeleteBoardFn, UpdateBoardFn } from '@ideas-project/shared';
import useBoardStore from '../stores/BoardStore';
import { onMounted, onUnmounted, provide } from 'vue';

const boardStore = useBoardStore()

provide<UpdateBoardFn>('updateBoard', boardStore.updateBoardAction)
provide<DeleteBoardFn>('deleteBoard', boardStore.deleteBoardAction)

onMounted(boardStore.loadBoards)
onUnmounted(boardStore.resetStore)
</script>

<template>
  <Skeleton
    v-if="boardStore.state.value.isLoading"
    height="6rem"
  />
  <BoardList
    v-else
    :list="boardStore.state.value.boards"
  />
</template>
