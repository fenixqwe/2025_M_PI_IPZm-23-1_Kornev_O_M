<script setup lang="ts">
import { ArchiveIdeaFn, DeleteIdeaFn, IdeasList, UpdateIdeaFn } from '@ideas-project/shared';
import useIdeaStore from '../stores/IdeaStore';
import { onMounted, onUnmounted, provide } from 'vue';

const ideaStore = useIdeaStore()

provide<UpdateIdeaFn>('updateIdea', ideaStore.updateIdeaFunc)
provide<DeleteIdeaFn>('deleteIdea', ideaStore.deleteIdeaAction)
provide<ArchiveIdeaFn>('archiveIdea', ideaStore.archiveIdeaAction)

onMounted(ideaStore.loadIdeas)
onUnmounted(ideaStore.resetStore)
</script>

<template>
  <Skeleton
    v-if="ideaStore.state.value.isLoading"
    height="6rem"
  />
  <IdeasList
    v-else
    :ideas="ideaStore.state.value.ideas"
  />
</template>
