import { createRouter, createWebHistory } from 'vue-router';

const routes = [
  {
    path: '/',
    component: () => import('../pages/BoardsPage.vue'),
  },
  {
    path: '/ideas/:board_id',
    component: () => import('../pages/IdeasPage.vue'),
  }
]

const router = createRouter({
  history: createWebHistory(),
  routes,
})

export default router
