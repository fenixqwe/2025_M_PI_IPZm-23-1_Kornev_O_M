<script setup lang="ts">
import {
  CreateBoardBtn,
  CreateIdeaBtn,
  FilterBtn,
  MainBlockWrapper,
  MainHeader,
  SearchBar
} from '@ideas-project/shared';
import { useRoute } from 'vue-router';
import useIdeaStore from './stores/IdeaStore';
import useBoardStore from './stores/BoardStore';

const route = useRoute()

const ideaStore = useIdeaStore()
const boardStore = useBoardStore()
</script>

<template>
  <MainHeader />
  <MainBlockWrapper>
    <div class="flex items-center justify-between w-full mb-[30px] relative">
      <div class="absolute left-1/2 transform -translate-x-1/2 w-[40%]">
        <SearchBar
          v-if="$route.path.includes('ideas')"
          :search-string="ideaStore.state.value.searchString"
          :change-search-string="ideaStore.searchIdeas"
        />
        <SearchBar
          v-else
          :search-string="boardStore.state.value.searchString"
          :change-search-string="boardStore.searchBoards"
        />
      </div>

      <div class="flex gap-2 ml-auto">
        <FilterBtn
          v-if="route.path.includes('ideas')"
          :filter-func="ideaStore.filterIdeas"
        />
        <CreateIdeaBtn
          v-if="route.path.includes('ideas')"
          :create-idea="ideaStore.createIdea"
        />
        <CreateBoardBtn
          v-else
          :create-board="boardStore.createBoard"
        />
      </div>
    </div>
    <div class="w-full">
      <RouterView />
    </div>
  </MainBlockWrapper>
</template>
