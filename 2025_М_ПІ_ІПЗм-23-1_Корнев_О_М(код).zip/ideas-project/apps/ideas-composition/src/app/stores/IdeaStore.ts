import { ref } from 'vue';
import { createIdea, Idea, IdeasAPI, updateIdeaData } from '@ideas-project/shared';
import { useRoute } from 'vue-router';

interface State {
  ideas: Idea[]
  searchString: string
  isLoading: boolean
}

const state = ref<State>({
  ideas: [],
  searchString: '',
  isLoading: false
})

// Mutations \\

function setIdeas(allIdeas: Idea[]) {
  state.value.ideas = allIdeas
}

function changeIsLoading(loadingState: boolean) {
  state.value.isLoading = loadingState
}

function addIdea(idea: Idea) {
  state.value.ideas.unshift(idea)
}

function updateIdea(updatedIdea: Idea) {
  state.value.ideas[state.value.ideas.findIndex((idea: Idea) => idea.idea_id === updatedIdea.idea_id)] = updatedIdea
}

function deleteIdea(ideaID: string) {
  state.value.ideas = state.value.ideas.filter((idea: Idea) => idea.idea_id !== ideaID)
}

function changeSearchString(value: string) {
  state.value.searchString = value;
}

function archiveIdea(ideaID: string, isArchived: boolean) {
  state.value.ideas[state.value.ideas.findIndex((idea: Idea) => idea.idea_id === ideaID)].is_archived = !isArchived;
}

// Actions \\


export default function useIdeaStore() {
  const route = useRoute()

  const createIdea = async (ideaData: createIdea) => {
    try {
      const response = await IdeasAPI.createIdea(ideaData)
      addIdea(response.data.data);
    } catch (error) {
      console.log(error)
    }
  }

  const loadIdeas = async () => {
    try {
      changeIsLoading(true)
      const response = await IdeasAPI.getAllIdeasOnCertainBoard(route.params.board_id as string)
      setIdeas(response.data.data || [])
      changeIsLoading(false)
    } catch (error) {
      console.log(error)
      changeIsLoading(false)
    }
  }

  const updateIdeaFunc = async (updateIdeaData: updateIdeaData, ideaID: string) => {
    try {
      const response = await IdeasAPI.updateIdea(updateIdeaData, ideaID)
      updateIdea(response.data.data)
    } catch (error) {
      console.log(error)
    }
  }

  const deleteIdeaAction = async (ideaID: string) => {
    try {
      await IdeasAPI.deleteIdea(ideaID)
      deleteIdea(ideaID)
    } catch (error) {
      console.log(error)
    }
  }

  const archiveIdeaAction = async (ideaID: string, isArchived: boolean) => {
    try {
      await IdeasAPI.archiveIdea(ideaID, !isArchived)
      archiveIdea(ideaID, isArchived)
    } catch (error) {
      console.log(error)
    }
  }

  const searchIdeas = async (value: string) => {
    try {
      changeSearchString(value)
      const response = await IdeasAPI.searchIdeas(state.value.searchString, route.params.board_id as string)
      setIdeas(response.data.data || [])
    } catch (error) {
      console.log(error)
    }
  }

  const filterIdeas = async (status: { name: string } | null) => {
    try {
      const isArchived = status?.name === 'Archived' ? true : status?.name === 'None Archived' ? false : undefined;
      const response = await IdeasAPI.getAllIdeasOnCertainBoard(route.params.board_id as string, isArchived)
      setIdeas(response.data.data || [])
    } catch (error) {
      console.log(error)
    }
  }

  const resetStore = () => {
    changeIsLoading(false)
    setIdeas([])
  };

  return {
    state,
    setIdeas,
    changeIsLoading,
    addIdea,
    updateIdea,
    deleteIdea,
    changeSearchString,
    loadIdeas,
    createIdea,
    archiveIdea,
    updateIdeaFunc,
    deleteIdeaAction,
    archiveIdeaAction,
    searchIdeas,
    filterIdeas,
    resetStore
  }
}
