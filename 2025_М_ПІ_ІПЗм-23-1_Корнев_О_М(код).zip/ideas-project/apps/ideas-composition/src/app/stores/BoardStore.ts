import { ref } from 'vue';
import { Board, BoardAPI, createBoard } from '@ideas-project/shared';

interface State {
  boards: Board[]
  searchString: string
  isLoading: boolean
}

const state = ref<State>({
  boards: [],
  searchString: '',
  isLoading: false
})

function setBoards(allBoards: Board[]) {
  state.value.boards = allBoards
}

function changeIsLoading(loadingState: boolean) {
  state.value.isLoading = loadingState;
}

function addBoard(board: Board) {
  state.value.boards.push(board);
}

function updateBoard(updatedBoard: Board) {
  state.value.boards[state.value.boards.findIndex((board: Board) => board.board_id === updatedBoard.board_id)] = updatedBoard
}

function deleteBoard(boardID: string) {
  state.value.boards = state.value.boards.filter((board: Board) => board.board_id !== boardID);
}

function changeSearchString(value: string) {
  state.value.searchString = value;
}

function testBoards(boards: Board[]) {
  state.value.boards = [...state.value.boards, ...boards]
}

// Actions \\

const createBoard = async (boardData: createBoard) => {
  try {
    const response = await BoardAPI.createBoard(boardData)
    let data = [];
    data.push(response.data.data);
    console.time('createBoard');
    testBoards(data);
    console.timeEnd('createBoard');
  } catch (error) {
    console.log(error)
  }
}

const loadBoards = async () => {
  try {
    changeIsLoading(true)
    const response = await BoardAPI.getAllBoards()
    setBoards(response.data.data || []);
    changeIsLoading(false)
  } catch (error) {
    console.log(error)
    changeIsLoading(false)
  }
}

const updateBoardAction = async (updatedTitle: string, boardID: string) => {
  try {
    const response = await BoardAPI.updateBoard(updatedTitle, boardID)
    updateBoard(response.data.data)
  } catch (error) {
    console.log(error)
  }
}

const deleteBoardAction = async (boardID: string) => {
  try {
    await BoardAPI.deleteBoard(boardID)
    deleteBoard(boardID)
  } catch (error) {
    console.log(error)
  }
}

const searchBoards = async (value: string) => {
  try {
    changeSearchString(value)
    const response = await BoardAPI.searchBoard(state.value.searchString)
    setBoards(response.data.data || [])
  } catch (error) {
    console.log(error)
  }
}

const resetStore = () => {
  changeIsLoading(false);
  setBoards([]);
}

export default function useBoardStore() {
  return {
    state,
    setBoards,
    addBoard,
    updateBoard,
    deleteBoard,
    loadBoards,
    createBoard,
    updateBoardAction,
    deleteBoardAction,
    searchBoards,
    resetStore
  };
}
