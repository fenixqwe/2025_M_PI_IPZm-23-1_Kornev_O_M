import './styles.css';
import { createApp } from 'vue';
import App from './app/App.vue';
import PrimeVue from 'primevue/config';
import Aura from '@primevue/themes/aura';
import { ConfirmationService, ToastService } from 'primevue';
import router from './app/router/router';
import 'primeicons/primeicons.css'

const app = createApp(App);
app.use(PrimeVue, {
  theme: {
    preset: Aura,
    options: {
      prefix: 'p',
      cssLayer: {
        name: 'primevue',
        order: 'tailwind-base, primevue, tailwind-utilities'
      }
    }
  }
}).use(ConfirmationService)
  .use(router)
  .use(ToastService)
  .mount('#root');
