const { createGlobPatternsForDependencies } = require('@nx/vue/tailwind');
const { join } = require('path');

/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    join(__dirname, 'index.html'),
    join(__dirname, 'src/**/*!(*.stories|*.spec).{vue,ts,tsx,js,jsx}'),
    ...createGlobPatternsForDependencies(__dirname),
  ],
  theme: {
    extend: {
      gridTemplateColumns: {
        'auto-fill-minmax': 'repeat(auto-fill, minmax(300px, 1fr))',
      },
      gridTemplateRows: {
        'auto-fit-230': 'repeat(auto-fit, 230px)',
      },
      colors: {
        //Text colors
        'main-text-color': '#F8FAFC',
        'secondary-text-color': '#727F93',

        //Block background colors
        'main-block-color': '#23272F',
      },
      backgroundImage: {
        'main-title-gradient': 'linear-gradient(270.17deg, #0075FF 0%, #CD68AB 100%)',
      }
    },
  },
  plugins: [],
};
