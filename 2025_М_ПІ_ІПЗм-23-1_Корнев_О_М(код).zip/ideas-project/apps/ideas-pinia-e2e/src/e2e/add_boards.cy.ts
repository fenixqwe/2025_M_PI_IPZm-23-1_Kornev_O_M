describe('Добавление 20 досок через форму', () => {
  it('должно создать 20 досок через UI', () => {
    cy.visit('/')
    const startTime = performance.now();

    for (let i = 0; i < 100; i++) {
      cy.get('.pi-plus').should('be.visible').click()

      cy.get('input#title')
        .should('be.visible')
        .clear({ force: true });

      cy.get('input#title').type(`Board ${i + 1}`);

      cy.get('button[type="submit"]')
        .should('be.visible')
        .as('submitButton');

      cy.get('@submitButton').click()

      cy.get('button[type="submit"]').should('not.exist');
    }

    cy.get('.board-item').should('have.length', 100);

    const endTime = performance.now();
    cy.log(`Время выполнения: ${endTime - startTime} мс`)
  });
});
