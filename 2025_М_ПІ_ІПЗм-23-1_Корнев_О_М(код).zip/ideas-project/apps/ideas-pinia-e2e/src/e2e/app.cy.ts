import { getGreeting } from '../support/app.po';

describe('ideas-pinia-e2e', () => {
  beforeEach(() => cy.visit('/'));

  it('should display welcome message', () => {
    getGreeting().contains(/BoardFlow/);
  });
});
