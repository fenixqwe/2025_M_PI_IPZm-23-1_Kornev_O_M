import { BoardAPI, createBoard } from '@ideas-project/shared';
// eslint-disable-next-line @nx/enforce-module-boundaries
import { useStore } from 'vuex';

export const useBoardService = () => {
  const boardStore = useStore();

  const createBoard = async (boardData: createBoard) => {
    try {
      const response = await BoardAPI.createBoard(boardData)

      let data = [];
      data.push(response.data.data);
      console.time('createBoard');
      boardStore.commit('Boards/testBoards', data);
      console.timeEnd('createBoard');

      // console.time('createBoard');
      // boardStore.commit('Boards/addBoard', response.data.data);
      // console.timeEnd('createBoard');
    } catch (error) {
      console.log(error)
    }
  }

  const loadBoards = async () => {
    try {
      boardStore.commit('Boards/changeIsLoading',true)
      const response = await BoardAPI.getAllBoards()
      boardStore.commit('Boards/setBoards', response.data.data || []);
      boardStore.commit('Boards/changeIsLoading',false)
    } catch (error) {
      console.log(error)
      boardStore.commit('Boards/changeIsLoading',false)
    }
  }

  const updateBoard = async (updatedTitle: string, boardID: string) => {
    try {
      const response = await BoardAPI.updateBoard(updatedTitle, boardID)
      boardStore.commit('Boards/updateBoard', response.data.data)
    } catch (error) {
      console.log(error)
    }
  }

  const deleteBoard = async (boardID: string) => {
    try {
      await BoardAPI.deleteBoard(boardID)
      boardStore.commit('Boards/deleteBoard', boardID)
    } catch (error) {
      console.log(error)
    }
  }

  const searchBoards = async (value: string) => {
    try {
      boardStore.commit('Boards/changeSearchString', value)
      const response = await BoardAPI.searchBoard(boardStore.state.Boards.searchString)
      boardStore.commit('Boards/setBoards', response.data.data || [])
    } catch (error) {
      console.log(error)
    }
  }

  const resetStore = () => {
    boardStore.commit('Boards/changeIsLoading',false)
    boardStore.commit('Boards/setBoards', []);
  }

  return {createBoard, loadBoards, updateBoard, deleteBoard, searchBoards, resetStore}
}
