import { createIdea, IdeasAPI, updateIdeaData } from '@ideas-project/shared';
import { useRoute } from 'vue-router';
import { useStore } from 'vuex';

export const useIdeasService = () => {
  const ideaStore = useStore()
  const route = useRoute()

  const createIdea = async (ideaData: createIdea) => {
    try {
      const response = await IdeasAPI.createIdea(ideaData)
      ideaStore.commit('Ideas/addIdea', response.data.data);
    } catch (error) {
      console.log(error)
    }
  }

  const loadIdeas = async () => {
    try {
      ideaStore.commit('Ideas/changeIsLoading', true)
      const response = await IdeasAPI.getAllIdeasOnCertainBoard(route.params.board_id as string)
      ideaStore.commit('Ideas/setIdeas', response.data.data || [])
      ideaStore.commit('Ideas/changeIsLoading', false)
    } catch (error) {
      console.log(error)
      ideaStore.commit('Ideas/changeIsLoading', false)
    }
  }

  const updateIdeaFunc = async (updateIdeaData: updateIdeaData, ideaID: string) => {
    try {
      const response = await IdeasAPI.updateIdea(updateIdeaData, ideaID)
      ideaStore.commit('Ideas/updateIdea', response.data.data)
    } catch (error) {
      console.log(error)
    }
  }

  const deleteIdea = async (ideaID: string) => {
    try {
      await IdeasAPI.deleteIdea(ideaID)
      ideaStore.commit('Ideas/deleteIdea', ideaID)
    } catch (error) {
      console.log(error)
    }
  }

  const archiveIdea = async (ideaID: string, isArchived: boolean) => {
    try {
      await IdeasAPI.archiveIdea(ideaID, !isArchived)
      ideaStore.commit('Ideas/archiveIdea', {ideaID, isArchived})
    } catch (error) {
      console.log(error)
    }
  }

  const searchIdeas = async (value: string) => {
    try {
      ideaStore.commit('Ideas/changeSearchString', value)
      const response = await IdeasAPI.searchIdeas(ideaStore.state.Ideas.searchString, route.params.board_id as string)
      ideaStore.commit('Ideas/setIdeas', response.data.data || [])
    } catch (error) {
      console.log(error)
    }
  }

  const filterIdeas = async (status: { name: string } | null) => {
    try {
      const isArchived = status?.name === 'Archived' ? true : status?.name === 'None Archived' ? false : undefined;
      const response = await IdeasAPI.getAllIdeasOnCertainBoard(route.params.board_id as string, isArchived)
      ideaStore.commit('Ideas/setIdeas', response.data.data || [])
    } catch (error) {
      console.log(error)
    }
  }

  const resetStore = () => {
    ideaStore.commit('Ideas/changeIsLoading', false)
    ideaStore.commit('Ideas/setIdeas', [])
  };

  return {createIdea, loadIdeas, updateIdeaFunc, deleteIdea, archiveIdea, searchIdeas, filterIdeas, resetStore}
}
