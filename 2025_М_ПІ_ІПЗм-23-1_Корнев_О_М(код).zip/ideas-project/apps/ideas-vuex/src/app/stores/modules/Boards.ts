import { Board } from '@ideas-project/shared';

interface State {
  boards: Board[]
  searchString: string
  isLoading: boolean
}

const state = (): State => ({
  boards: [],
  searchString: '',
  isLoading: false
})

const getters = {

}

const actions = {

}

const mutations = {
  setBoards(state: State, allBoards: Board[]) {
    state.boards = allBoards
  },
  changeIsLoading(state: State, loadingState: boolean) {
    state.isLoading = loadingState
  },
  addBoard(state: State, board: Board) {
    state.boards.push(board)
  },
  updateBoard(state: State, updatedBoard: Board) {
    state.boards[state.boards.findIndex((board: Board) => board.board_id === updatedBoard.board_id)] = updatedBoard
  },
  deleteBoard(state: State, boardID: string) {
    state.boards = state.boards.filter((board: Board) => board.board_id !== boardID);
  },
  changeSearchString(state: State, value: string) {
    state.searchString = value;
  },
  testBoards(state: State, boards: Board[]) {
    state.boards = [...state.boards, ...boards]
  }
}

export default {
  namespaced: true,
  state,
  getters,
  actions,
  mutations
}
