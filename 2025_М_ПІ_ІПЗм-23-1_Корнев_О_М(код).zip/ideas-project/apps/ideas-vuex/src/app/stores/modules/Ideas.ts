import { Idea } from '@ideas-project/shared';

interface State {
  ideas: Idea[]
  searchString: string
  isLoading: boolean
}

const state = (): State => ({
  ideas: [],
  searchString: '',
  isLoading: false
})

const getters = {

}

const actions = {

}

const mutations = {
  setIdeas(state: State, allIdeas: Idea[]) {
    state.ideas = allIdeas
  },
  changeIsLoading(state: State, loadingState: boolean) {
    state.isLoading = loadingState
  },
  addIdea(state: State, idea: Idea) {
    state.ideas.unshift(idea)
  },
  updateIdea(state: State, updatedIdea: Idea) {
    state.ideas[state.ideas.findIndex((idea: Idea) => idea.idea_id === updatedIdea.idea_id)] = updatedIdea
  },
  deleteIdea(state: State, ideaID: string) {
    state.ideas = state.ideas.filter((idea: Idea) => idea.idea_id !== ideaID)
  },
  changeSearchString(state: State, value: string) {
    state.searchString = value;
  },
  archiveIdea(state: State, {ideaID, isArchived}: {ideaID: string, isArchived: boolean}) {
    state.ideas[state.ideas.findIndex((idea: Idea) => idea.idea_id === ideaID)].is_archived = !isArchived;
  },
}

export default {
  namespaced: true,
  state,
  getters,
  actions,
  mutations
}
