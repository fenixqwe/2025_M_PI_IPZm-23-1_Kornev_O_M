import { createLogger, createStore } from 'vuex';
import Boards from './modules/Boards';
import Ideas from './modules/Ideas';

export default createStore({
  modules: {
    Boards,
    Ideas
  },
  strict: true,
  plugins: [createLogger()]
})
