<script setup lang="ts">
import { useStore } from 'vuex';
import { useBoardService } from '../services/BoardsService';
import { onMounted, onUnmounted, provide } from 'vue';
import { BoardList, DeleteBoardFn, UpdateBoardFn } from '@ideas-project/shared';

const store = useStore()
const boardStore = store.state.Boards
const boardService = useBoardService()

provide<UpdateBoardFn>('updateBoard', boardService.updateBoard)
provide<DeleteBoardFn>('deleteBoard', boardService.deleteBoard)

onMounted(boardService.loadBoards)
onUnmounted(boardService.resetStore)
</script>

<template>
  <Skeleton
    v-if="boardStore.isLoading"
    height="6rem"
  />
  <BoardList
    v-else
    :list="boardStore.boards"
  />
</template>
