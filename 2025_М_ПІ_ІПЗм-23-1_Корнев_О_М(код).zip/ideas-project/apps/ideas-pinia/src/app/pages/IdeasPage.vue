<script setup lang="ts">
import { ArchiveIdeaFn, DeleteIdeaFn, IdeasList, UpdateIdeaFn } from '@ideas-project/shared';
import { onMounted, onUnmounted, provide } from 'vue';
import { useIdeaStore } from '../stores/IdeaStore';
import { useIdeasService } from '../services/IdeasService';

const ideaStore = useIdeaStore()
const ideasService = useIdeasService()

provide<UpdateIdeaFn>('updateIdea', ideasService.updateIdeaFunc)
provide<DeleteIdeaFn>('deleteIdea', ideasService.deleteIdea)
provide<ArchiveIdeaFn>('archiveIdea', ideasService.archiveIdea)

onMounted(ideasService.loadIdeas)
onUnmounted(ideasService.resetStore)
</script>

<template>
  <Skeleton
    v-if="ideaStore.isLoading"
    height="6rem"
  />
  <IdeasList
    v-else
    :ideas="ideaStore.ideas"
  />
</template>
