import { BoardAPI, createBoard } from '@ideas-project/shared';
import { useBoardStore } from '../stores/BoardStore';

export const useBoardService = () => {
  const boardStore = useBoardStore();

  const createBoard = async (boardData: createBoard) => {
    try {
      const response = await BoardAPI.createBoard(boardData)
      let data = [];
      data.push(response.data.data);
      boardStore.testBoards(data);
    } catch (error) {
      console.log(error)
    }
  }

  const loadBoards = async () => {
    try {
      boardStore.changeIsLoading(true)
      const response = await BoardAPI.getAllBoards()
      boardStore.setBoards(response.data.data || []);
      boardStore.changeIsLoading(false)
    } catch (error) {
      console.log(error)
      boardStore.changeIsLoading(false)
    }
  }

  const updateBoard = async (updatedTitle: string, boardID: string) => {
    try {
      const response = await BoardAPI.updateBoard(updatedTitle, boardID)
      boardStore.updateBoard(response.data.data)
    } catch (error) {
      console.log(error)
    }
  }

  const deleteBoard = async (boardID: string) => {
    try {
      await BoardAPI.deleteBoard(boardID)
      boardStore.deleteBoard(boardID)
    } catch (error) {
      console.log(error)
    }
  }

  const searchBoards = async (value: string) => {
    try {
      boardStore.changeSearchString(value)
      const response = await BoardAPI.searchBoard(boardStore.searchString)
      boardStore.setBoards(response.data.data || [])
    } catch (error) {
      console.log(error)
    }
  }

  const resetStore = () => {
    boardStore.changeIsLoading(false);
    boardStore.setBoards([]);
  }

  return {createBoard, loadBoards, updateBoard, deleteBoard, searchBoards, resetStore}
}
