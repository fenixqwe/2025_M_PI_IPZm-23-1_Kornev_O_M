import { useIdeaStore } from '../stores/IdeaStore';
import { createIdea, IdeasAPI, updateIdeaData } from '@ideas-project/shared';
import { useRoute } from 'vue-router';

export const useIdeasService = () => {
  const ideaStore = useIdeaStore()
  const route = useRoute()

  const createIdea = async (ideaData: createIdea) => {
    try {
      const response = await IdeasAPI.createIdea(ideaData)
      ideaStore.addIdea(response.data.data);
    } catch (error) {
      console.log(error)
    }
  }

  const loadIdeas = async () => {
    try {
      ideaStore.changeIsLoading(true)
      const response = await IdeasAPI.getAllIdeasOnCertainBoard(route.params.board_id as string)
      ideaStore.setIdeas(response.data.data || [])
      ideaStore.changeIsLoading(false)
    } catch (error) {
      console.log(error)
      ideaStore.changeIsLoading(false)
    }
  }

  const updateIdeaFunc = async (updateIdeaData: updateIdeaData, ideaID: string) => {
    try {
      const response = await IdeasAPI.updateIdea(updateIdeaData, ideaID)
      ideaStore.updateIdea(response.data.data)
    } catch (error) {
      console.log(error)
    }
  }

  const deleteIdea = async (ideaID: string) => {
    try {
      await IdeasAPI.deleteIdea(ideaID)
      ideaStore.deleteIdea(ideaID)
    } catch (error) {
      console.log(error)
    }
  }

  const archiveIdea = async (ideaID: string, isArchived: boolean) => {
    try {
      await IdeasAPI.archiveIdea(ideaID, !isArchived)
      ideaStore.archiveIdea(ideaID, isArchived)
    } catch (error) {
      console.log(error)
    }
  }

  const searchIdeas = async (value: string) => {
    try {
      ideaStore.changeSearchString(value)
      const response = await IdeasAPI.searchIdeas(ideaStore.searchString, route.params.board_id as string)
      ideaStore.setIdeas(response.data.data || [])
    } catch (error) {
      console.log(error)
    }
  }

  const filterIdeas = async (status: { name: string } | null) => {
    try {
      const isArchived = status?.name === 'Archived' ? true : status?.name === 'None Archived' ? false : undefined;
      const response = await IdeasAPI.getAllIdeasOnCertainBoard(route.params.board_id as string, isArchived)
      ideaStore.setIdeas(response.data.data || [])
    } catch (error) {
      console.log(error)
    }
  }

  const resetStore = () => {
    ideaStore.changeIsLoading(false)
    ideaStore.setIdeas([])
  };

  return {createIdea, loadIdeas, updateIdeaFunc, deleteIdea, archiveIdea, searchIdeas, filterIdeas, resetStore}
}
