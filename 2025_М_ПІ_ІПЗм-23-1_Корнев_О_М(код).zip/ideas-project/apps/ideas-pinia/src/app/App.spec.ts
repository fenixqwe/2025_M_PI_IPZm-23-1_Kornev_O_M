import { describe, it, expect } from 'vitest';
import { mount } from '@vue/test-utils';
import App from './App.vue';
import PrimeVue from 'primevue/config';
import { ConfirmationService, ToastService } from 'primevue';

describe('App', () => {
  it('renders properly', async () => {
    const wrapper = mount(App, {
      global: {
        plugins: [PrimeVue, ConfirmationService, ToastService],
      },
    });
    expect(wrapper.exists()).toBe(true);
  });
});
