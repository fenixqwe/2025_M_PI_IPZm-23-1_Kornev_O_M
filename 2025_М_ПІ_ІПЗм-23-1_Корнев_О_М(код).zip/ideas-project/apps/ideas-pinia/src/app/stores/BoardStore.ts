import { defineStore } from 'pinia';
import { Board } from '@ideas-project/shared';
import { markRaw } from 'vue';

export const useBoardStore = defineStore('BoardStore', {
  state: () => ({
    boards: [] as Board[],
    searchString: '',
    isLoading: false
  }),
  actions: {
    setBoards(allBoards: Board[]) {
      this.boards = allBoards;
    },
    changeIsLoading(loadingState: boolean) {
      this.isLoading = loadingState;
    },
    addBoard(board: Board) {
      this.boards.push(markRaw(board));
    },
    updateBoard(updatedBoard: Board) {
      const index = this.boards.findIndex((board: Board) => board.board_id === updatedBoard.board_id);
      if (index !== -1) {
        this.boards[index] = markRaw(updatedBoard);
      }
    },
    deleteBoard(boardID: string) {
      this.boards = this.boards.filter((board: Board) => board.board_id !== boardID);
    },
    changeSearchString(value: string) {
      this.searchString = value;
    },
    testBoards(boards: Board[]) {
      const rawBoards = boards.map(board => markRaw(board));
      this.boards = [...this.boards, ...rawBoards];
    }
  }
});
