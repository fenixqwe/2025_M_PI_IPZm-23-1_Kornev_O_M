import { defineStore } from 'pinia';
import { Idea } from '@ideas-project/shared';

export const useIdeaStore = defineStore('IdeaStore', {
  state: (): {ideas: Idea[], isLoading: boolean, searchString: string} => ({
    ideas: [],
    isLoading: false,
    searchString: ''
  }),
  getters: {},
  actions: {
    setIdeas(allIdeas: Idea[]) {
      this.ideas = allIdeas
    },
    changeIsLoading(loadingState: boolean) {
      this.isLoading = loadingState
    },
    addIdea(idea: Idea) {
      this.ideas.unshift(idea)
    },
    updateIdea(updatedIdea: Idea) {
      this.ideas[this.ideas.findIndex((idea: Idea) => idea.idea_id === updatedIdea.idea_id)] = updatedIdea
    },
    deleteIdea(ideaID: string) {
      this.ideas = this.ideas.filter((idea: Idea) => idea.idea_id !== ideaID)
    },
    changeSearchString(value: string) {
      this.searchString = value;
    },
    archiveIdea(ideaID: string, isArchived: boolean) {
      this.ideas[this.ideas.findIndex((idea: Idea) => idea.idea_id === ideaID)].is_archived = !isArchived;
    }
  }
})
