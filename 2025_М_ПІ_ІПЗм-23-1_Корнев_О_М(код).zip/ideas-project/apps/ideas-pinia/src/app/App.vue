<script setup lang="ts">
import {
  CreateBoardBtn,
  CreateIdeaBtn,
  FilterBtn,
  MainBlockWrapper,
  MainHeader,
  SearchBar
} from '@ideas-project/shared';

import { useBoardStore } from './stores/BoardStore';
import { useIdeaStore } from './stores/IdeaStore';
import { useBoardService } from './services/BoardsService';
import { useIdeasService } from './services/IdeasService';
import { useRoute } from 'vue-router';

const route = useRoute()

const boardStore = useBoardStore()
const ideaStore = useIdeaStore()

const boardsService = useBoardService()
const ideasService = useIdeasService()

</script>

<template>
  <MainHeader />
  <MainBlockWrapper>
    <div class="flex items-center justify-between w-full mb-[30px] relative">
      <div class="absolute left-1/2 transform -translate-x-1/2 w-[40%]">
        <SearchBar
          v-if="$route.path.includes('ideas')"
          :search-string="ideaStore.searchString"
          :change-search-string="ideasService.searchIdeas"
        />
        <SearchBar
          v-else
          :search-string="boardStore.searchString"
          :change-search-string="boardsService.searchBoards"
        />
      </div>

      <div class="flex gap-2 ml-auto">
        <FilterBtn
          v-if="route.path.includes('ideas')"
          :filter-func="ideasService.filterIdeas"
        />
        <CreateIdeaBtn
          v-if="route.path.includes('ideas')"
          :create-idea="ideasService.createIdea"
        />
        <CreateBoardBtn
          v-else
          :create-board="boardsService.createBoard"
        />
      </div>
    </div>
    <div class="w-full">
      <RouterView />
    </div>
  </MainBlockWrapper>
</template>
