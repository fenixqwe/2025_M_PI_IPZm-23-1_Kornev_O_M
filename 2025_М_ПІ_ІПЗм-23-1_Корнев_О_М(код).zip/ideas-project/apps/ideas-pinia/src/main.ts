import './styles.css';
import { createApp } from 'vue';
import App from './app/App.vue';
import PrimeVue from 'primevue/config';
import Aura from '@primevue/themes/aura';
import 'primeicons/primeicons.css';
import { ConfirmationService, ToastService } from 'primevue';
import router from './app/router/router';
import { createPinia } from 'pinia';

const pinia = createPinia();
const app = createApp(App);

app.use(PrimeVue, {
  theme: {
    preset: Aura,
    options: {
      prefix: 'p',
      cssLayer: {
        name: 'primevue',
        order: 'tailwind-base, primevue, tailwind-utilities'
      }
    }
  }
}).use(ConfirmationService)
  .use(router)
  .use(ToastService)
  .use(pinia)
  .mount('#root');
