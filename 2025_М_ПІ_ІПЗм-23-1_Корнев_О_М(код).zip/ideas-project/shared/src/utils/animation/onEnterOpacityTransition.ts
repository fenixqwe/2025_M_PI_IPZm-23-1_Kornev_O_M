import { animate, stagger } from 'motion';

export default function onEnterOpacityTransition(el : Element, done: () => void) {
  animate(el, { opacity: 1 }, { duration: 0.4, delay: stagger(0.1) })
  done()
}
