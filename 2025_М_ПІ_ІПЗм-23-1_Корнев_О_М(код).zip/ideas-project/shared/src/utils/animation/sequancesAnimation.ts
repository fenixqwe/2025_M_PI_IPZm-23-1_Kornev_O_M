import { nextTick, watch } from 'vue';
import { animate, stagger } from 'motion';
import { Board } from '../../types/board/Board';
import { Idea } from '../../types/idea/Idea';

export default async (data: Board[] | Idea[], elements: any, keyframes: { opacity: number[]; y: number[] }) => {
  await nextTick();

  if (data.length > 0 && elements.value.length > 0) {
    animate(elements.value, keyframes, { duration: 0.3, delay: stagger(0.1) });
  }

  watch(
    () => [...data],
    async (newList, oldList) => {
      await nextTick();

      if (newList.length > oldList.length) {
        animate(elements.value, keyframes, { duration: 0.3, delay: stagger(0.1) });
      } else if (newList.length < oldList.length) {
        const removedIndex = oldList.findIndex(item => !newList.includes(item));

        if (removedIndex !== -1 && elements.value[removedIndex]) {
          animate(elements.value[removedIndex], { opacity: [1, 0], y: [0, -20] }, { duration: 0.3 }).then(() => {
            elements.value.splice(removedIndex, 1);
          });
        }
      }
    },
    { deep: true }
  );
};
