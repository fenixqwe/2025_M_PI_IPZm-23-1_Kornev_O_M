import type confirmModalProps from '../../types/modal/comfirmModalProps';

const confirmModal = ({ message, group, detail, confirm, toast, deleteFunc } : confirmModalProps) => {
  confirm.require({
    group,
    message,
    header: 'Confirm Deletion',
    icon: 'pi pi-info-circle',
    rejectLabel: 'Cancel',
    rejectProps: {
      label: 'Cancel',
      severity: 'secondary',
      outlined: true
    },
    acceptProps: {
      label: 'Delete',
      severity: 'danger'
    },
    accept: () => {
      deleteFunc()
      toast.add({
        severity: 'success',
        summary: 'Deleted',
        detail,
        group,
        life: 3000
      })
    },
    reject: () => {
      toast.add({
        severity: 'error',
        summary: 'Canceled',
        detail: 'Deletion canceled',
        group,
        life: 3000
      })
    }
  })
}

export default confirmModal
