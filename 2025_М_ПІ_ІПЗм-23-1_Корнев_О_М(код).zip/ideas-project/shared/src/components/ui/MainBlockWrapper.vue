<script setup lang="ts">
import onEnterOpacityTransition from '../../utils/animation/onEnterOpacityTransition';
</script>

<template>
  <Transition
    :css="false"
    appear
    @appear="onEnterOpacityTransition"
  >
    <div class="justify-center items-center flex h-full mx-[50px] pb-[50px] opacity-0">
      <div class="px-[30px] py-[20px] rounded-xl bg-main-block-color flex flex-col w-full">
        <slot />
      </div>
    </div>
  </Transition>
</template>
