<script setup lang="ts">
import onEnterOpacityTransition from '../../utils/animation/onEnterOpacityTransition';
import { onMounted, ref } from 'vue';
import { animate } from 'motion';

const spanRef = ref<HTMLElement | null>(null);

// onMounted(() => {
//   if (spanRef.value) {
//     animate(spanRef.value, { backgroundPosition: '0% 0%' }, {
//       duration: 1.5,
//       easing: 'ease-in-out',
//     });
//   }
// });
</script>

<template>
<!--  <Transition-->
<!--    :css="false"-->
<!--    appear-->
<!--    @appear="onEnterOpacityTransition"-->
<!--  >-->
<!--    <div-->
<!--      v-once-->
<!--      class="flex items-center justify-center w-full text-center mb-[40px] text-7xl font-semibold opacity-0"-->
<!--    >-->
<!--      <h1-->
<!--        class="text-main-text-color cursor-pointer w-fit"-->
<!--        @click="$router.push('/')"-->
<!--      >-->
<!--        Board<span-->
<!--          ref="spanRef"-->
<!--          class="bg-main-title-gradient bg-clip-text text-transparent bg-[length:200%_100%] bg-[position:100%_0]"-->
<!--        >Flow</span>-->
<!--      </h1>-->
<!--    </div>-->
<!--  </Transition>-->
  <div
    v-once
    class="flex items-center justify-center w-full text-center mb-[40px] text-7xl font-semibold"
  >
    <h1
      class="text-main-text-color cursor-pointer w-fit"
      @click="$router.push('/')"
    >
      Board<span
      ref="spanRef"
      class="bg-main-title-gradient bg-clip-text text-transparent bg-[length:200%_100%] bg-[position:100%_0]"
    >Flow</span>
    </h1>
  </div>
</template>
