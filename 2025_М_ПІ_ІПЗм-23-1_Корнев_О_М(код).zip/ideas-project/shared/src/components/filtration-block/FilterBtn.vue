<script setup lang="ts">
import { animate, stagger } from 'motion';
import { ref, watch } from 'vue';
import Popover from 'primevue/popover';

interface Props {
  filterFunc: (status: { name: string } | null) => Promise<void>;
}

const props = defineProps<Props>()
const op = ref();
const selectedFiltration = ref();
const cities = ref([
  { name: 'Archived' },
  { name: 'None Archived' },
]);

watch(selectedFiltration, (newValue) => {
  props.filterFunc(newValue);
});

function onEnter(el : Element, done: () => void) {
  animate(el, { opacity: 1 }, { duration: 0.3, delay: stagger(0.1) })
  done()
}

const toggle = (event: MouseEvent) => {
  op.value.toggle(event);
}
</script>

<template>
  <Transition
    :css="false"
    appear
    @appear="onEnter"
  >
    <div>
      <Button
        v-once
        icon="pi pi-filter"
        class="bg-[#333A45] hover:bg-[#384C53] max-w-[40px] flex items-center justify-center relative"
        severity="secondary"
        variant="text"
        @click="toggle"
      />
      <Popover
        ref="op"
        unstyled
        class="mt-[5px]"
      >
        <Listbox
          v-model="selectedFiltration"
          :options="cities"
          optionLabel="name"
          checkmark
          class="w-full bg-[#18181b]"
        />
      </Popover>
    </div>
  </Transition>
</template>
