<script setup lang="ts">
import onEnterOpacityTransition from '../../utils/animation/onEnterOpacityTransition';

interface Props {
  searchString: string
  changeSearchString: (searchString: string) => void
}

const props = defineProps<Props>();
</script>

<template>
  <Transition
    :css="false"
    appear
    @appear="onEnterOpacityTransition"
  >
    <InputGroup>
      <InputText
        :value="props.searchString"
        placeholder="Search..."
        class="bg-[#333A45] font-semibold"
        @input="props.changeSearchString(($event.target as HTMLInputElement).value)"
        @keyup.enter="props.changeSearchString(($event.target as HTMLInputElement).value)"
      />
      <InputGroupAddon class="bg-[#333A45] font-semibold">
        <Button
          icon="pi pi-search"
          class="hover:bg-[#384C53]"
          severity="secondary"
          variant="text"
          @click="props.changeSearchString(props.searchString)"
        />
      </InputGroupAddon>
    </InputGroup>
  </Transition>
</template>
