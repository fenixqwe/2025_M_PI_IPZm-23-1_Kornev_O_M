<script setup lang="ts">
import { defineAsyncComponent, onMounted, ref } from 'vue';
import sequancesAnimation from '../../utils/animation/sequancesAnimation';
import NoElements from './no-elements/NoElements.vue';
import { Idea } from '../../types/idea/Idea';

interface Props {
  ideas: Idea[]
}

const IdeaItem = defineAsyncComponent(() => import('./idea/IdeaItem.vue'))

const props = defineProps<Props>()

const elements = ref<HTMLElement[]>([])

onMounted(() => sequancesAnimation(props.ideas, elements, { opacity: [0, 1], y: [20, 0] }))
</script>

<template>
  <div
    v-if="props.ideas.length > 0"
    class="relative max-h-[650px] overflow-scroll scrollbar-hidden grid grid-cols-[repeat(4,_minmax(300px,_1fr))] max-[800px]:grid-cols-1 max-[1250px]:grid-cols-2 max-[1500px]:grid-cols-3 gap-5"
  >
    <div
      v-for="idea in props.ideas"
      :key="idea.idea_id"
      ref="elements"
      v-memo="[idea]"
      class="w-full h-full opacity-0"
    >
      <IdeaItem
        :idea="idea"
      />
    </div>
  </div>
  <NoElements v-else />
</template>
