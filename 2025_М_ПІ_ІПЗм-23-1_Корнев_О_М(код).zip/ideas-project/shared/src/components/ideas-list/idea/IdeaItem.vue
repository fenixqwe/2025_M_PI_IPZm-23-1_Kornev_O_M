<script setup lang="ts">
import ItemManagement from '../../data-management/ItemManagement.vue';
import { inject, ref } from 'vue';
import { Form, FormResolverOptions } from '@primevue/forms';
import Toast from 'primevue/toast';
import ConfirmDialog from 'primevue/confirmdialog';
import { Idea } from '../../../types/idea/Idea';
import { useToast } from 'primevue';
import ContextMenu from 'primevue/contextmenu';
import { updateIdeaData } from '../../../types/idea/UpdateIdea';
import { UpdateIdeaFn } from '../../../types/idea/UpdateIdeaFn';
import { DeleteIdeaFn } from '../../../types/idea/DeleteIdeaFn';
import { ArchiveIdeaFn } from '../../../types/idea/ArchiveIdeaFn';


interface Props {
  idea: Idea
}

const toast = useToast()
const props = defineProps<Props>()

const updateIdea = inject<UpdateIdeaFn>('updateIdea')
const deleteIdea = inject<DeleteIdeaFn>('deleteIdea')
const archiveIdea = inject<ArchiveIdeaFn>('archiveIdea')

const menu = ref()
const visible = ref(false)
const initialValues = ref<updateIdeaData>({
  title: props.idea.title,
  description: props.idea.description
})
const contextMenu = ref()
const items = ref([{
    label: 'Archive',
    icon: 'pi pi-book',
    command: () => {
      if (!archiveIdea) return
      archiveIdea(props.idea.idea_id, props.idea.is_archived)
    }
}])

const toggle = (event: MouseEvent) => {
  event.stopPropagation()
  menu.value?.menu?.toggle(event);
}

const modalProps = {
  message: `Do you want to delete the idea "${props.idea.title}"?`,
  group: props.idea.idea_id,
  detail: `Idea "${props.idea.title}" deleted`
}

const changeEditModalStatus = (): void => {
  visible.value = true;
}

const resolver = ({ values } : FormResolverOptions) => {
  const errors: any = {}

  if (!values.title) {
    errors.title = [{ message: 'Title is required.' }]
  }

  return {
    errors
  }
}

const saveChanges = async ({valid}: {valid : boolean}) => {
  if (!valid) return;
  if (!updateIdea) return;

  visible.value = false;

  const updatedData: Partial<updateIdeaData> = {};

  if (initialValues.value.title !== props.idea.title) {
    updatedData.title = initialValues.value.title;
  }
  if (initialValues.value.description !== props.idea.description) {
    updatedData.description = initialValues.value.description;
  }

  if (Object.keys(updatedData).length === 0) {
    return;
  }

  updateIdea(updatedData, props.idea.idea_id);
  toast.add({
    severity: "success",
    summary: "Idea updated successfully.",
    life: 3000,
  });
}

const deleteFunc = () => {
  if (!deleteIdea) return
  deleteIdea(props.idea.idea_id)
}

const hideModalFunc = () => {
  initialValues.value = {
    title: props.idea.title,
    description: props.idea.description
  }
}

const onImageRightClick = (event: MouseEvent) => {
  contextMenu.value.show(event);
};
</script>

<template>
  <Toast
    position="bottom-right"
    :group="props.idea.idea_id"
  />
  <ConfirmDialog :group="props.idea.idea_id" />
  <ContextMenu
    ref="contextMenu"
    class="mt-[5px] min-w-0"
    :model="items"
  />
  <div
    class="bg-[#26353A] rounded-2xl flex justify-center items-center flex-col relative w-full"
    aria-haspopup="true"
    :aria-disabled="props.idea.is_archived"
    @contextmenu="onImageRightClick"
  >
    <div
      v-if="props.idea.is_archived"
      class="absolute bg-[#26353A] rounded-2xl w-full h-full z-20 opacity-[0.8]"
    />
    <div class="p-[40px]">
      <svg
        width="88"
        height="84"
        viewBox="0 0 88 84"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <path
          d="M15.0391 0L10.6445 4.39453L17.1875 10.9375L21.582 6.54297L15.0391 0ZM72.4609 0L65.918 6.54297L70.3125 10.9375L76.8555 4.39453L72.4609 0ZM43.75 1.95312C42.7246 1.96534 41.6748 2.02638 40.625 2.14844C40.5884 2.14844 40.564 2.14844 40.5273 2.14844C27.8564 3.60106 17.7734 13.8428 16.0156 26.4648C14.6118 36.6211 18.7988 45.8252 25.7812 51.7578C28.772 54.3213 30.6152 57.7393 31.25 61.2305V79.9805H38.3789C39.4653 81.8482 41.4429 83.1055 43.75 83.1055C46.0571 83.1055 48.0347 81.8482 49.1211 79.9805H56.25V67.4805H56.543V63.7695C56.543 59.1919 58.9233 54.5654 62.793 50.9766C67.9688 45.8008 71.875 38.4399 71.875 29.9805C71.875 14.5386 59.1675 1.80666 43.75 1.95312ZM43.75 8.20312C55.8228 8.03222 65.625 17.9199 65.625 29.9805C65.625 36.5234 62.5977 42.2852 58.3984 46.4844L58.4961 46.582C54.2969 50.5005 51.6113 55.6274 50.8789 61.2305H37.207C36.5234 55.8716 34.2163 50.6958 29.8828 46.9727C24.3652 42.2729 21.0693 35.2173 22.168 27.2461C23.5352 17.395 31.5186 9.48487 41.3086 8.39844C42.1265 8.30078 42.9443 8.21534 43.75 8.20312ZM0 29.9805V36.2305H9.375V29.9805H0ZM78.125 29.9805V36.2305H87.5V29.9805H78.125ZM17.1875 55.2734L10.6445 61.8164L15.0391 66.2109L21.582 59.668L17.1875 55.2734ZM70.3125 55.2734L65.918 59.668L72.4609 66.2109L76.8555 61.8164L70.3125 55.2734ZM37.5 67.4805H50V73.7305H37.5V67.4805Z"
          fill="#F8FAFC"
        />
      </svg>
    </div>
    <div class="bg-[#F8FAFC] text-[#03003C] w-full h-[50%] p-[20px] rounded-bl-[18px] rounded-br-[18px] font-semibold">
      <h2
        v-memo="[props.idea.title]"
        class="!text-[30px] pb-[15px]"
      >
        {{ props.idea.title }}
      </h2>
      <div class="absolute w-full h-[1px] bg-[#1E293B] left-0" />
      <p
        v-if="props.idea.description"
        v-memo="[props.idea.description]"
        class="pt-[15px] text-[#5A5A5A]"
      >
        {{ props.idea.description }}
      </p>
      <p
        v-else
        class="pt-[15px] text-[#5A5A5A]"
      >
        No Description
      </p>
    </div>
    <div>
      <div
        class="absolute top-[10px] right-[10px] bg-[#F8FAFC] rounded-full px-[10px] flex justify-center items-center cursor-pointer"
        @click="toggle($event)"
      >
        <i
          class="pi pi-ellipsis-h text-[#9A9A9A] text-[20px]"
        />
      </div>
      <ItemManagement
        ref="menu"
        :editFunc="changeEditModalStatus"
        :modalProps="modalProps"
        :deleteFunc="deleteFunc"
      />
    </div>
  </div>
  <Dialog
    v-model:visible="visible"
    modal
    header="Edit Idea"
    class="w-[25rem]"
    @hide="hideModalFunc"
  >
    <Form
      v-slot="$form"
      :initialValues
      :resolver
      @submit="saveChanges"
    >
      <div class="flex flex-col items-center gap-[5px] mb-4">
        <label
          for="title"
          class="font-semibold w-full pl-[5px]"
        >Title</label>
        <InputText
          id="title"
          v-model.lazy="initialValues.title"
          name="title"
          class="flex-auto w-full bg-[#26353A]"
          autocomplete="off"
        />
        <Message
          v-if="$form.title?.invalid"
          severity="error"
          size="small"
          variant="simple"
          class="flex-auto w-full"
        >
          {{ $form.title.error?.message }}
        </Message>
      </div>
      <div class="flex flex-col items-center gap-[5px] mb-8">
        <label
          for="description"
          class="font-semibold w-full pl-[5px]"
        >Description</label>
        <Textarea
          id="description"
          v-model.lazy="initialValues.description"
          name="description"
          auto-resize
          class="flex-auto w-full bg-[#26353A]"
        />
      </div>
      <div class="flex gap-2">
        <Button
          type="button"
          label="Cancel"
          severity="secondary"
          class="w-full text-red-500"
          @click="visible = false"
        />
        <Button
          type="submit"
          label="Save"
          class="w-full"
        />
      </div>
    </Form>
  </Dialog>
</template>
