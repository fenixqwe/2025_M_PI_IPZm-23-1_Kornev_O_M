<script setup lang="ts">
import { computed, ref } from 'vue';
import { useConfirm } from 'primevue/useconfirm';
import { useToast } from 'primevue';
import confirmModal from '../../utils/modal/confirmModal';

interface Props {
  modalProps: {
    message: string
    group: string
    detail: string
  }
  editFunc: (event?: Event) => void
  deleteFunc: () => void
}

const props = defineProps<Props>()

const confirm = useConfirm();
const toast = useToast()

const menu = ref();

const items = computed(() => [
  {
    label: 'Edit',
    icon: 'pi pi-pencil',
    command: () => {
      props.editFunc()
    }
  },
  {
    label: 'Delete',
    icon: 'pi pi-trash',
    command: () => {
      confirmModal({
        ...props.modalProps,
        confirm,
        toast,
        deleteFunc: props.deleteFunc,
      })
    }
  }
])

defineExpose({ menu });
</script>

<template>
  <Menu
    v-once
    ref="menu"
    :model="items"
    :popup="true"
    class="mt-[5px] min-w-0"
  >
    <template
      #item="{ item, props }"
    >
      <a
        v-if="item.label == 'Delete'"
        class="flex items-center"
        v-bind="props.action"
      >
        <span
          class="text-red-500"
          :class="item.icon"
        />
        <span class="text-red-500">{{ item.label }}</span>
      </a>
      <a
        v-else
        class="flex items-center"
        v-bind="props.action"
      >
        <span :class="item.icon" />
        <span>{{ item.label }}</span>
      </a>
    </template>
  </Menu>
</template>
