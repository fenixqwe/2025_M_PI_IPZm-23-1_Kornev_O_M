<script setup lang="ts">
import { ref } from 'vue';
import { Form, FormResolverOptions } from '@primevue/forms';
import { useRoute } from 'vue-router';
import { useToast } from 'primevue';
import Toast from 'primevue/toast';

interface Props {
  createIdea: (ideaData: any) => void;
}

interface createIdeaData {
  title: string;
  description?: string;
  board_id: string;
}

const props = defineProps<Props>()

const route = useRoute()

const visible = ref(false)

const toast = useToast()

const initialValues = ref<createIdeaData>({
  title: '',
  description: '',
  board_id: route.params.board_id as string,
})

const resolver = ({ values } : FormResolverOptions) => {
  const errors: any = {}

  if (!values.title) {
    errors.title = [{ message: 'Title is required.' }]
  }

  return {
    errors
  }
}

const create = ({valid}: {valid : boolean}) => {
  if (valid) {
    visible.value = false
    props.createIdea(initialValues.value)
    toast.add({
      severity: 'success',
      summary: 'Idea created successfully.',
      life: 3000
    })
  }
}
</script>

<template>
  <Toast position="bottom-right" />
  <Button
    v-once
    icon="pi pi-plus"
    class="bg-[#333A45] hover:bg-[#384C53] max-w-[40px]"
    severity="secondary"
    variant="text"
    @click="visible = true"
  />
  <Dialog
    v-model:visible="visible"
    modal
    header="Create Idea"
    class="w-[25rem]"
  >
    <Form
      v-slot="$form"
      :initialValues
      :resolver
      @submit="create"
    >
      <div class="flex flex-col items-center gap-[5px] mb-4">
        <label
          for="title"
          class="font-semibold w-full pl-[5px]"
        >Title</label>
        <InputText
          id="title"
          v-model.lazy="initialValues.title"
          name="title"
          class="flex-auto w-full bg-[#26353A]"
          fluid
        />
        <Message
          v-if="$form.title?.invalid"
          severity="error"
          size="small"
          variant="simple"
          class="flex-auto w-full"
        >
          {{ $form.title.error?.message }}
        </Message>
      </div>
      <div class="flex flex-col items-center gap-[5px] mb-4">
        <label
          for="description"
          class="font-semibold w-full pl-[5px]"
        >Description</label>
        <Textarea
          id="description"
          v-model.lazy="initialValues.description"
          name="description"
          auto-resize
          class="flex-auto w-full bg-[#26353A]"
          fluid
        />
      </div>
      <div class="flex gap-2">
        <Button
          type="button"
          label="Cancel"
          severity="secondary"
          class="w-full text-red-500"
          @click="visible = false"
        />
        <Button
          type="submit"
          label="Create"
          class="w-full"
        />
      </div>
    </Form>
  </Dialog>
</template>
