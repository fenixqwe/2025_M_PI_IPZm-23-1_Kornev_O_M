<script setup lang="ts">
import { defineAsyncComponent, inject, nextTick, ref } from 'vue';
import ConfirmDialog from 'primevue/confirmdialog';
import Toast from 'primevue/toast';
import { useRouter } from 'vue-router';
import { Board } from '../../../types/board/Board';
import { useToast } from 'primevue';
import { UpdateBoardFn } from '../../../types/board/UpdateBoardFn';
import { DeleteBoardFn } from '../../../types/board/DeleteBoardFn';

interface Props {
  board: Board;
}

const props = defineProps<Props>()
const modalProps = {
  message: `Do you want to delete the board "${props.board.title}"?`,
  group: props.board.board_id,
  detail: `Board ${props.board.title} deleted`
}

const menu = ref()
const isEditing = ref(false)
const newTitle = ref(props.board.title)
const inputRef = ref()

const updateBoard = inject<UpdateBoardFn>('updateBoard')
const deleteBoard = inject<DeleteBoardFn>('deleteBoard')

const router = useRouter()
const toast = useToast()

const ItemManagement = defineAsyncComponent(() => import('../../data-management/ItemManagement.vue'))

const toggle = (event: MouseEvent) => {
  event.stopPropagation()
  menu.value?.menu?.toggle(event);
}

const startEditing = (event: any) => {
  event?.stopPropagation()
  isEditing.value = true
  nextTick(() => inputRef.value.focus())
}

const saveChanges = async () => {
  isEditing.value = false

  if (!updateBoard) return

  if (newTitle.value.trim().length && newTitle.value !== props.board.title) {
    updateBoard(newTitle.value, props.board.board_id)
    toast.add({
      severity: 'success',
      summary: 'Board updated successfully.',
      life: 3000,
      group: props.board.board_id
    })
  } else if (!newTitle.value.trim()) {
    newTitle.value = props.board.title
    toast.add({
      severity: 'error',
      summary: 'Canceled',
      detail: 'Title is required',
      group: props.board.board_id,
      life: 3000
    })
  }
}

const confirmEditing = () => {
  inputRef.value?.blur()
}

const deleteFunc = () => {
  if (!deleteBoard) return
  deleteBoard(props.board.board_id)
}

</script>

<template>
  <Toast
    position="bottom-right"
    :group="props.board.board_id"
  />
  <ConfirmDialog :group="props.board.board_id" />

  <div
    class="w-full bg-[#26353A] flex justify-between items-center p-[25px] rounded-lg board-item"
    @click="router.push(`/ideas/${props.board.board_id}`)"
  >
    <div class="max-w-[50px] max-h-[39px] mr-[20px] flex justify-center items-center">
      <svg
        width="61"
        height="49"
        viewBox="0 0 61 49"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <path
          d="M6.1 49L54.9 49C56.5178 49 58.0694 48.3547 59.2134 47.206C60.3573 46.0574 61 44.4995 61 42.875L61 6.125C61 4.50055 60.3573 2.94263 59.2134 1.79397C58.0694 0.645313 56.5178 0 54.9 0L6.1 0C4.48218 0 2.93062 0.645313 1.78665 1.79397C0.642677 2.94263 0 4.50055 0 6.125L0 42.875C0 44.4995 0.642677 46.0574 1.78665 47.206C2.93062 48.3547 4.48218 49 6.1 49ZM39.65 12.25C39.65 11.4378 39.9713 10.6588 40.5433 10.0845C41.1153 9.51015 41.8911 9.1875 42.7 9.1875C43.5089 9.1875 44.2847 9.51015 44.8567 10.0845C45.4287 10.6588 45.75 11.4378 45.75 12.25L45.75 24.5C45.75 25.3122 45.4287 26.0912 44.8567 26.6655C44.2847 27.2398 43.5089 27.5625 42.7 27.5625C41.8911 27.5625 41.1153 27.2398 40.5433 26.6655C39.9713 26.0912 39.65 25.3122 39.65 24.5V12.25ZM27.45 12.25C27.45 11.4378 27.7713 10.6588 28.3433 10.0845C28.9153 9.51015 29.6911 9.1875 30.5 9.1875C31.3089 9.1875 32.0847 9.51015 32.6567 10.0845C33.2287 10.6588 33.55 11.4378 33.55 12.25V30.625C33.55 31.4372 33.2287 32.2162 32.6567 32.7905C32.0847 33.3648 31.3089 33.6875 30.5 33.6875C29.6911 33.6875 28.9153 33.3648 28.3433 32.7905C27.7713 32.2162 27.45 31.4372 27.45 30.625L27.45 12.25ZM15.25 12.25C15.25 11.4378 15.5713 10.6588 16.1433 10.0845C16.7153 9.51015 17.4911 9.1875 18.3 9.1875C19.1089 9.1875 19.8847 9.51015 20.4567 10.0845C21.0287 10.6588 21.35 11.4378 21.35 12.25L21.35 36.75C21.35 37.5622 21.0287 38.3412 20.4567 38.9155C19.8847 39.4898 19.1089 39.8125 18.3 39.8125C17.4911 39.8125 16.7153 39.4898 16.1433 38.9155C15.5713 38.3412 15.25 37.5622 15.25 36.75L15.25 12.25Z"
          fill="white"
          fill-opacity="0.9"
        />
      </svg>
    </div>

    <div class="flex items-start w-full text-[23px] font-semibold py-[6px] px-[10px]">
      <h2
        v-if="!isEditing"
        v-memo="[props.board.title]"
        class="max-w-[200px] overflow-ellipsis overflow-hidden whitespace-nowrap"
        @click="startEditing"
      >
        {{ props.board.title }}
      </h2>
      <input
        v-else
        ref="inputRef"
        v-model.lazy="newTitle"
        class="px-[5px]"
        @blur="saveChanges"
        @click="(event) => event.stopPropagation()"
        @keyup.enter="confirmEditing"
      >
    </div>

    <div class="relative cursor-pointer">
      <i
        class="pi pi-ellipsis-v text-[#F8FAFC]"
        style="font-size: 1.5rem"
        aria-controls="overlay_menu"
        @click="toggle($event)"
      />
      <ItemManagement
        ref="menu"
        :edit-func="startEditing"
        :delete-func="deleteFunc"
        :modal-props="modalProps"
      />
    </div>
  </div>
</template>
