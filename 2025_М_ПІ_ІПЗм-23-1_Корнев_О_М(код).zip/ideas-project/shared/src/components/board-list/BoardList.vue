<script setup lang="ts">
import { defineAsyncComponent, nextTick, ref, watch } from 'vue';
import sequancesAnimation from '../../utils/animation/sequancesAnimation';
import NoElements from './no-elements/NoElements.vue';
import type { Board } from '../../types/board/Board';

interface Props {
  list: Board[]
}

const BoardItem = defineAsyncComponent(() => import('./board/BoardItem.vue'));

const props = defineProps<Props>()

const elements = ref<HTMLElement[]>([])

// watch(
//   () => props.list,
//   async () => {
//     await nextTick();
//     await sequancesAnimation(props.list, elements, { opacity: [0, 1], y: [20, 0] });
//   },
//   { deep: true, immediate: true }
// );
</script>

<template>
  <div
    v-if="props.list.length > 0"
    class="flex flex-col gap-[10px] max-h-[650px] overflow-auto scrollbar-hidden"
  >
    <div
      v-for="board in props.list"
      :key="board.board_id"
      ref="elements"
      v-memo="[board]"
      class="opacity-1"
    >
      <BoardItem
        :board="board"
      />
    </div>
  </div>
  <NoElements v-else />
</template>
