export type UpdateBoardFn = (newTitle: string, boardId: string) => void
