export interface Board {
  board_id: string;
  title: string;
  updated_at: string;
  created_at: string;
}
