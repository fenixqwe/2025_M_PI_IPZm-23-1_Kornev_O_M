export type DeleteBoardFn = (boardID: string) => void
