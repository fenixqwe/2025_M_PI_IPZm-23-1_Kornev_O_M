export interface createBoard {
  title: string;
}
