import type { ToastServiceMethods } from 'primevue';

export default interface confirmModalProps {
  message: string;
  group: string;
  detail: string;
  confirm: any;
  toast: ToastServiceMethods;
  deleteFunc: () => void;
}
