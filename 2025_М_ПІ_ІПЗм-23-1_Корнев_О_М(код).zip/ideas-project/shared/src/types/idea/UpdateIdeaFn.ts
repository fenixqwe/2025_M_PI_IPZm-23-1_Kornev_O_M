import { updateIdeaData } from './UpdateIdea';

export type UpdateIdeaFn = (updateIdeaData: updateIdeaData, ideaID: string) => void
