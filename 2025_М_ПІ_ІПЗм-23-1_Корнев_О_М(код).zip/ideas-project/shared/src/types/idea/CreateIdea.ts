export interface createIdea {
  title: string;
  description?: string;
  board_id: string;
}
