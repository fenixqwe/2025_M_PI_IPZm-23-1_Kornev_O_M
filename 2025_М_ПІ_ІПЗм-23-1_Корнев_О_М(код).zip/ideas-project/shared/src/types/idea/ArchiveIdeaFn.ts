export type ArchiveIdeaFn = (ideaID: string, isArchived: boolean) => void
