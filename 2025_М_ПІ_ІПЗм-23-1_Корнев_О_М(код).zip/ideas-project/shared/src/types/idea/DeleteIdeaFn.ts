export type DeleteIdeaFn = (ideaID: string) => void
