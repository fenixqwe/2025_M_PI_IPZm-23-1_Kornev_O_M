export interface updateIdeaData {
  title?: string;
  description?: string;
}
