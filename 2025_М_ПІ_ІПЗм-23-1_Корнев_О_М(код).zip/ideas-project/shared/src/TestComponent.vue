<script setup lang="ts">

</script>

<template>
  <p class="text-yellow-500">
    TestComponent
  </p>
</template>

<style scoped>

</style>
