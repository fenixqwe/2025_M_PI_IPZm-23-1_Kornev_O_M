export {default as MainBlockWrapper} from './components/ui/MainBlockWrapper.vue'
export {default as MainHeader} from './components/ui/MainHeader.vue'
export {default as SearchBar} from './components/filtration-block/SearchBar.vue'
export {default as FilterBtn} from './components/filtration-block/FilterBtn.vue'
export {default as CreateBoardBtn} from './components/data-management/CreateBoardBtn.vue'
export {default as CreateIdeaBtn} from './components/data-management/CreateIdeaBtn.vue'
export {default as BoardList} from './components/board-list/BoardList.vue'
export {default as IdeasList} from './components/ideas-list/IdeasList.vue'

//API
export {default as BoardAPI} from './services/board-service/BoardAPI'
export {default as IdeasAPI} from './services/idea-service/IdeaAPI'

//TYPES
export * from './types/board/CreateBoard'
export * from './types/board/UpdateBoardFn'
export * from './types/board/DeleteBoardFn'
export * from './types/board/Board'

export * from './types/idea/CreateIdea'
export * from './types/idea/Idea'
export * from './types/idea/UpdateIdea'
export * from './types/idea/UpdateIdeaFn'
export * from './types/idea/DeleteIdeaFn'
export * from './types/idea/ArchiveIdeaFn'
