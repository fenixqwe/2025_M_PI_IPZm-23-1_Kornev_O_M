import API from '../API';
import { createBoard } from '../../types/board/CreateBoard';

export default {
  getAllBoards() {
    return API().get('/boards/getAllBoards')
  },
  createBoard(createBoardData: createBoard) {
    return API().post('/boards/create', createBoardData)
  },
  updateBoard(updatedTitle: string, boardID: string) {
    return API().patch(`/boards/${boardID}`, {title: updatedTitle})
  },
  deleteBoard(boardID: string) {
    return API().delete(`/boards/${boardID}`)
  },
  searchBoard(searchString: string) {
    return API().get(`/boards/search?query=${searchString}`)
  }
}
