import axios from 'axios';

export default(url='http://localhost:5000/v1') => {
  return axios.create({
    baseURL: url,
  })
}
