import API from '../API';
import { updateIdeaData } from '../../types/idea/UpdateIdea';

interface createIdeaData {
  title: string;
  description?: string;
  board_id: string;
}

export default {
  getAllIdeasOnCertainBoard(boardID: string, isArchived?: boolean) {
    return API().get(`/ideas/board/${boardID}?isArchived=${isArchived !== undefined ? isArchived : ''}`)
  },
  createIdea(ideaData: createIdeaData) {
    return API().post(`/ideas/create`, ideaData)
  },
  updateIdea(updateIdeaData: updateIdeaData, ideaID: string) {
    return API().patch(`/ideas/${ideaID}`, updateIdeaData)
  },
  deleteIdea(ideaID: string) {
    return API().delete(`/ideas/${ideaID}`)
  },
  searchIdeas(searchString: string, boardID: string) {
    return API().get(`/ideas/board/${boardID}/search?query=${searchString}`)
  },
  archiveIdea(ideaID: string, isArchived: boolean) {
    return API().patch(`/ideas/${ideaID}`, {is_archived: isArchived})
  },
}
